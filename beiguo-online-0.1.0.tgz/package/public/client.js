// public/client.js
// 北国密令 · 联机MVP客户端（无框架）

const $ = (id) => document.getElementById(id);

const state = {
  ws: null,
  roomCode: null,
  clientToken: localStorage.getItem('beiguo_clientToken') || null,
  nick: localStorage.getItem('beiguo_nick') || '',
  snapshot: null
};

function toast(msg) {
  const el = $('toast');
  el.textContent = String(msg);
  el.style.display = 'block';
  clearTimeout(toast._t);
  toast._t = setTimeout(() => { el.style.display = 'none'; }, 2600);
}

function wsUrl() {
  const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
  return `${proto}//${location.host}`;
}

function connectWs() {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(wsUrl());
    state.ws = ws;

    ws.onopen = () => resolve(ws);
    ws.onerror = (e) => reject(e);

    ws.onmessage = (ev) => {
      let msg;
      try { msg = JSON.parse(ev.data); } catch { return; }

      if (msg.type === 'HELLO') {
        // ignore
        return;
      }

      if (msg.type === 'ERROR') {
        toast(msg.message || '发生错误');
        return;
      }

      if (msg.type === 'ROOM_CREATED' || msg.type === 'ROOM_JOINED') {
        state.roomCode = msg.roomCode;
        state.clientToken = msg.clientToken;
        localStorage.setItem('beiguo_clientToken', state.clientToken);
        setMode('room');
        $('roomInfo').innerHTML = `房间号：<span class="pill">${state.roomCode}</span>`;
        return;
      }

      if (msg.type === 'ROOM_SNAPSHOT') {
        state.snapshot = msg;
        renderRoom();
        return;
      }
    };

    ws.onclose = () => {
      toast('连接已断开，刷新页面会自动重连（token保留）。');
    };
  });
}

function send(type, payload = {}) {
  if (!state.ws || state.ws.readyState !== 1) {
    toast('未连接到服务器。');
    return;
  }
  state.ws.send(JSON.stringify({
    type,
    roomCode: state.roomCode,
    clientToken: state.clientToken,
    ...payload
  }));
}

function setMode(mode) {
  $('modeJoin').classList.toggle('hidden', mode !== 'join');
  $('modeRoom').classList.toggle('hidden', mode !== 'room');
}

function sanitizeRoomCode(s) {
  return String(s || '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 12);
}

// --- UI: Join/Create ---
$('nick').value = state.nick;
$('btnCreate').onclick = async () => {
  const nick = $('nick').value.trim();
  if (!nick) return toast('请先输入昵称');
  state.nick = nick;
  localStorage.setItem('beiguo_nick', nick);

  if (!state.ws || state.ws.readyState !== 1) await connectWs();
  state.ws.send(JSON.stringify({ type: 'CREATE_ROOM', nick, clientToken: state.clientToken }));
};

$('btnJoin').onclick = async () => {
  const nick = $('nick').value.trim();
  const roomCode = sanitizeRoomCode($('roomCode').value);
  if (!nick) return toast('请先输入昵称');
  if (!roomCode) return toast('请输入房间号');

  state.nick = nick;
  localStorage.setItem('beiguo_nick', nick);

  if (!state.ws || state.ws.readyState !== 1) await connectWs();
  state.ws.send(JSON.stringify({ type: 'JOIN_ROOM', nick, roomCode, clientToken: state.clientToken }));
};

$('btnCopy').onclick = async () => {
  if (!state.roomCode) return;
  try {
    await navigator.clipboard.writeText(state.roomCode);
    toast('房间号已复制');
  } catch {
    toast('复制失败（浏览器不支持）');
  }
};

$('btnReset').onclick = () => send('START_GAME');
$('btnAdvance').onclick = () => send('ADVANCE_PHASE');

// --- Roster rendering (host controls) ---
function isHost() {
  const snap = state.snapshot;
  return snap && snap.room && snap.self && snap.room.hostToken === snap.self.token;
}

function renderRoster(roster) {
  const tbody = $('rosterTable').querySelector('tbody');
  tbody.innerHTML = '';

  for (const row of roster) {
    const tr = document.createElement('tr');

    const tdNick = document.createElement('td');
    tdNick.textContent = row.nick;

    const tdRole = document.createElement('td');
    tdRole.textContent = row.role + (row.seat ? `(${row.seat})` : '');

    const tdOps = document.createElement('td');

    if (isHost()) {
      // assign seat buttons
      const mkBtn = (text, onClick) => {
        const b = document.createElement('button');
        b.textContent = text;
        b.style.marginRight = '6px';
        b.onclick = onClick;
        return b;
      };

      tdOps.appendChild(mkBtn('设为A', () => send('HOST_ASSIGN_SEAT', { targetToken: row.token, seat: 'A' })));
      tdOps.appendChild(mkBtn('设为B', () => send('HOST_ASSIGN_SEAT', { targetToken: row.token, seat: 'B' })));
      tdOps.appendChild(mkBtn('设为裁判', () => send('HOST_ASSIGN_SEAT', { targetToken: row.token, seat: 'REF' })));
      tdOps.appendChild(mkBtn('设为观众', () => send('HOST_ASSIGN_SEAT', { targetToken: row.token, seat: 'SPECTATOR' })));

      const t = document.createElement('button');
      t.className = 'danger';
      t.textContent = '转移房主';
      t.onclick = () => {
        if (!confirm('确定转移房主？你将失去房主权限。')) return;
        send('HOST_TRANSFER', { targetToken: row.token });
      };
      tdOps.appendChild(t);
    } else {
      tdOps.innerHTML = '<span class="muted">仅房主可操作</span>';
    }

    tr.appendChild(tdNick);
    tr.appendChild(tdRole);
    tr.appendChild(tdOps);
    tbody.appendChild(tr);
  }
}

// --- Board utilities ---
function cellName(r, c) {
  // 直接复用你裁判工具里常见的九宫格命名习惯：
  // (0,0)=NW, (0,1)=N, (0,2)=NE, (1,0)=W, (1,1)=C, (1,2)=E, (2,0)=SW, (2,1)=S, (2,2)=SE
  const map = [
    ['NW', 'N', 'NE'],
    ['W', 'C', 'E'],
    ['SW', 'S', 'SE']
  ];
  return map[r][c];
}

function renderBoard(root, boardId, view, sideForThisBoard, clickMode) {
  // clickMode: { enabled, piece: 'spy'|'hunter' }
  const board = document.createElement('div');
  board.className = 'grid';

  const truth = view.truth;

  const getPos = (s, key) => {
    if (view.kind === 'ref_view') {
      return truth[s][key];
    }
    // player_view
    if (view.side === s) return view.self[key];
    return null;
  };

  for (let r = 0; r < 3; r++) {
    for (let c = 0; c < 3; c++) {
      const cell = document.createElement('div');
      cell.className = 'cell';
      cell.dataset.r = String(r);
      cell.dataset.c = String(c);

      const small = document.createElement('small');
      small.textContent = cellName(r, c);

      const piece = document.createElement('div');
      piece.className = 'piece';

      const spy = getPos(sideForThisBoard, 'spyPos');
      const hunter = getPos(sideForThisBoard, 'hunterPos');

      const hereSpy = spy && spy.r === r && spy.c === c;
      const hereHunter = hunter && hunter.r === r && hunter.c === c;

      let label = '';
      if (hereSpy) label += '间';
      if (hereHunter) label += (label ? ' / ' : '') + '捕';
      piece.textContent = label;

      cell.appendChild(piece);
      cell.appendChild(small);

      if (clickMode?.enabled) {
        cell.onclick = () => {
          send('MOVE', {
            piece: clickMode.piece,
            to: { r, c }
          });
        };
      } else {
        cell.style.cursor = 'default';
      }

      board.appendChild(cell);
    }
  }

  root.innerHTML = '';
  root.appendChild(board);
}

function renderLog(container, entries) {
  const div = document.createElement('div');
  div.className = 'log';
  for (const e of entries) {
    const line = document.createElement('div');
    line.className = 'logLine';
    line.textContent = e.text;
    div.appendChild(line);
  }
  container.innerHTML = '';
  container.appendChild(div);
}

function renderPlayerView(view) {
  const root = document.createElement('div');

  const meta = document.createElement('div');
  meta.className = 'muted';
  meta.textContent = `你是玩家 ${view.side} · 回合 ${view.round} · 阶段 ${view.phase === 'deploy' ? '部署' : '追捕'}`;
  root.appendChild(meta);

  const hint = document.createElement('div');
  hint.style.marginTop = '6px';
  hint.innerHTML = `<span class="pill">操作说明</span> 部署阶段点格子移动“间”；追捕阶段点格子移动“捕”。`;
  root.appendChild(hint);

  const boardBox = document.createElement('div');
  boardBox.className = 'boardBox';
  boardBox.style.marginTop = '10px';

  const title = document.createElement('div');
  title.className = 'boardTitle';
  title.innerHTML = `<strong>你的棋盘（${view.side}）</strong><span class="pill">${view.phase === 'deploy' ? '点格子移动间' : '点格子移动捕'}</span>`;
  boardBox.appendChild(title);

  const boardRoot = document.createElement('div');
  boardBox.appendChild(boardRoot);

  renderBoard(boardRoot, 'self', view, view.side, {
    enabled: true,
    piece: view.phase === 'deploy' ? 'spy' : 'hunter'
  });

  root.appendChild(boardBox);

  // cards
  const cards = document.createElement('div');
  cards.className = 'card';
  cards.style.marginTop = '10px';
  const lines = Object.entries(view.self.cards)
    .filter(([, n]) => n > 0)
    .map(([name, n]) => ({ name, n }));

  const head = document.createElement('div');
  head.style.display = 'flex';
  head.style.alignItems = 'center';
  head.style.justifyContent = 'space-between';
  head.innerHTML = `<strong>你的锦囊</strong><span class="muted">本阶段已用锦囊：${view.cardsUsedThisPhase[view.side] ? '是' : '否'}</span>`;
  cards.appendChild(head);

  if (!lines.length) {
    const none = document.createElement('div');
    none.className = 'muted';
    none.style.marginTop = '6px';
    none.textContent = '无可用锦囊';
    cards.appendChild(none);
  } else {
    const list = document.createElement('div');
    list.style.display = 'flex';
    list.style.flexWrap = 'wrap';
    list.style.gap = '8px';
    list.style.marginTop = '8px';

    for (const it of lines) {
      const b = document.createElement('button');
      b.textContent = `${it.name} × ${it.n}`;
      b.disabled = view.cardsUsedThisPhase[view.side];

      b.onclick = () => {
        // 目前只对“宵禁令”做了真正效果，需要指定目标
        if (it.name === '宵禁令') {
          const target = prompt('宵禁令目标（A 或 B）：', view.side === 'A' ? 'B' : 'A');
          if (!target) return;
          send('PLAY_CARD', { cardName: it.name, payload: { target: target.toUpperCase() } });
          return;
        }
        send('PLAY_CARD', { cardName: it.name, payload: {} });
      };

      list.appendChild(b);
    }

    cards.appendChild(list);
  }

  root.appendChild(cards);

  // log
  const logBox = document.createElement('div');
  logBox.className = 'card';
  logBox.innerHTML = '<strong>你的可见日志</strong>';
  const logRoot = document.createElement('div');
  logRoot.style.marginTop = '8px';
  logBox.appendChild(logRoot);
  renderLog(logRoot, view.log);
  root.appendChild(logBox);

  return root;
}

function renderRefView(view) {
  const root = document.createElement('div');

  const meta = document.createElement('div');
  meta.className = 'muted';
  meta.textContent = `上帝视角 · 回合 ${view.truth.round} · 阶段 ${view.truth.phase === 'deploy' ? '部署' : '追捕'}`;
  root.appendChild(meta);

  const boards = document.createElement('div');
  boards.className = 'boards';
  boards.style.marginTop = '10px';

  const mkBoard = (side) => {
    const box = document.createElement('div');
    box.className = 'boardBox';
    const title = document.createElement('div');
    title.className = 'boardTitle';
    title.innerHTML = `<strong>${side} 方棋盘</strong><span class="pill">间/捕全可见</span>`;
    box.appendChild(title);
    const root = document.createElement('div');
    box.appendChild(root);
    renderBoard(root, `ref-${side}`, view, side, { enabled: false });
    return box;
  };

  boards.appendChild(mkBoard('A'));
  boards.appendChild(mkBoard('B'));
  root.appendChild(boards);

  const stat = document.createElement('div');
  stat.className = 'card';
  stat.style.marginTop = '10px';
  const truth = view.truth;
  const cardSummary = (s) => {
    const cards = truth[s].cards;
    const list = Object.entries(cards).filter(([, n]) => n > 0).map(([k, n]) => `${k}×${n}`);
    return list.join('，') || '无';
  };
  stat.innerHTML = `
    <div><strong>状态</strong></div>
    <div class="muted" style="margin-top:6px">A 冻结回合：${truth.A.frozenRounds}；B 冻结回合：${truth.B.frozenRounds}</div>
    <div class="muted">A 本阶段移动次数：${truth.movesThisPhase.A}；B 本阶段移动次数：${truth.movesThisPhase.B}</div>
    <div class="muted">A 本阶段已用锦囊：${truth.cardsUsedThisPhase.A ? '是' : '否'}；B：${truth.cardsUsedThisPhase.B ? '是' : '否'}</div>
    <div style="margin-top:8px"><span class="pill">A 手牌</span> <span class="muted">${cardSummary('A')}</span></div>
    <div style="margin-top:6px"><span class="pill">B 手牌</span> <span class="muted">${cardSummary('B')}</span></div>
  `;
  root.appendChild(stat);

  const logBox = document.createElement('div');
  logBox.className = 'card';
  logBox.innerHTML = '<strong>全量日志（裁判/观众可见）</strong>';
  const logRoot = document.createElement('div');
  logRoot.style.marginTop = '8px';
  logBox.appendChild(logRoot);
  renderLog(logRoot, view.log);
  root.appendChild(logBox);

  return root;
}

function renderRoom() {
  const snap = state.snapshot;
  if (!snap) return;

  const me = snap.self;
  const room = snap.room;
  const roster = snap.roster;

  // top controls
  $('myRole').textContent = `我的身份：${me.role}${me.seat ? `(${me.seat})` : ''}`;
  $('btnReset').disabled = !(room.refToken === me.token);
  $('btnAdvance').disabled = !(room.refToken === me.token);

  renderRoster(roster);

  // view
  const viewRoot = $('viewRoot');
  const view = snap.view;
  if (view.kind === 'player_view') {
    viewRoot.innerHTML = '';
    viewRoot.appendChild(renderPlayerView(view));
  } else {
    viewRoot.innerHTML = '';
    viewRoot.appendChild(renderRefView(view));
  }
}

// init
setMode('join');
connectWs().catch(() => toast('连接服务器失败'));
