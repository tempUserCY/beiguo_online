import express from 'express';
import http from 'http';
import { WebSocketServer } from 'ws';
import crypto from 'crypto';

/**
 * 北国密令 - 联机MVP服务器（裁判制）
 * - 房间号系统生成
 * - Host 默认裁判，可移交 Host（移交即失去房主权限）
 * - 裁判/观众上帝视角；玩家仅见自己视图
 * - 不做聊天
 */

const PORT = process.env.PORT ? Number(process.env.PORT) : 8787;

const app = express();
app.use(express.static('public'));

const server = http.createServer(app);
const wss = new WebSocketServer({ server });

/** @typedef {'HOST'|'REF'|'A'|'B'|'SPECTATOR'} Role */

function randCode(len = 6) {
  // 省事：大写字母+数字，排除易混淆字符
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let out = '';
  for (let i = 0; i < len; i++) out += alphabet[Math.floor(Math.random() * alphabet.length)];
  return out;
}

function newToken() {
  return crypto.randomBytes(16).toString('hex');
}

function clampNick(raw) {
  const s = String(raw ?? '').trim();
  // 允许中文/英文/数字/空格/下划线/中划线（避免乱七八糟控制字符）
  const cleaned = s.replace(/[^\p{Script=Han}\p{L}\p{N} _\-]/gu, '').slice(0, 16);
  return cleaned || '玩家';
}

function uniqNick(desired, takenSet) {
  if (!takenSet.has(desired)) return desired;
  let i = 2;
  while (takenSet.has(`${desired}#${i}`)) i++;
  return `${desired}#${i}`;
}

function defaultTruthState() {
  return {
    round: 1,
    phase: 'deploy', // 'deploy' | 'hunt'
    over: false,

    // 每阶段每方必须至少移动一次（没被宵禁）
    movesThisPhase: { A: 0, B: 0 },
    cardsUsedThisPhase: { A: false, B: false },

    A: {
      spyPos: null,
      hunterPos: null,
      frozenRounds: 0,
      cards: {
        '差役成群': 1,
        '幽径暗道': 1,
        '耳目线报': 1,
        '追猎犬': 1,
        '宵禁令': 1,
        '拿钱办事': 1,
        '细作入营': 1,
        '调虎离山': 1
      }
    },
    B: {
      spyPos: null,
      hunterPos: null,
      frozenRounds: 0,
      cards: {
        '差役成群': 1,
        '幽径暗道': 1,
        '耳目线报': 1,
        '追猎犬': 1,
        '宵禁令': 1,
        '拿钱办事': 1,
        '细作入营': 1,
        '调虎离山': 1
      }
    },

    // 事件日志（带可见性）
    // vis: 'ALL' | 'REF' | 'A' | 'B'
    log: []
  };
}

function nowIso() {
  return new Date().toISOString();
}

function addLog(state, { text, vis = 'ALL' }) {
  state.log.push({ t: nowIso(), vis, text });
}

function getAdj(a, b) {
  const dr = Math.abs(a.r - b.r);
  const dc = Math.abs(a.c - b.c);
  return (dr + dc === 1);
}

function validateMove(state, side, piece, to) {
  if (state.over) return { ok: false, err: '游戏已结束。' };
  if (side !== 'A' && side !== 'B') return { ok: false, err: '非法阵营。' };
  const p = state[side];
  if (p.frozenRounds > 0) return { ok: false, err: '你受到【宵禁令】影响，本回合无法行动。' };

  if (state.phase === 'deploy') {
    if (piece !== 'spy') return { ok: false, err: '部署阶段只能移动间谍。' };
  } else {
    if (piece !== 'hunter') return { ok: false, err: '追捕阶段只能部署/移动追捕者。' };
  }

  if (!to || !Number.isInteger(to.r) || !Number.isInteger(to.c) || to.r < 0 || to.r > 2 || to.c < 0 || to.c > 2) {
    return { ok: false, err: '目标格子非法。' };
  }

  const key = piece === 'spy' ? 'spyPos' : 'hunterPos';
  const from = p[key];

  // 第一次落子：允许任意格（更贴你裁判工具的体验）
  if (from == null) return { ok: true };

  // 默认规则：必须上下左右相邻
  if (!getAdj(from, to)) return { ok: false, err: '必须移动到上下左右相邻格。' };

  return { ok: true };
}

function applyMove(state, side, piece, to) {
  const check = validateMove(state, side, piece, to);
  if (!check.ok) return check;
  const key = piece === 'spy' ? 'spyPos' : 'hunterPos';
  state[side][key] = { r: to.r, c: to.c };
  state.movesThisPhase[side] += 1;

  // 日志：玩家移动对对方不可见（你要求玩家不知道对方移动方位）
  const label = piece === 'spy' ? '间谍' : '追捕者';
  addLog(state, { text: `R${state.round} · ${side}方移动${label}。`, vis: side });
  addLog(state, { text: `R${state.round} · ${side}方移动${label}：(${to.r},${to.c})`, vis: 'REF' });
  return { ok: true };
}

function canAdvancePhase(state) {
  if (state.over) return { ok: false, err: '游戏已结束。' };

  const needA = state.A.frozenRounds <= 0;
  const needB = state.B.frozenRounds <= 0;

  if ((needA && state.movesThisPhase.A === 0) || (needB && state.movesThisPhase.B === 0)) {
    return {
      ok: false,
      err: state.phase === 'deploy'
        ? '部署阶段：所有未被【宵禁令】影响的阵营，都必须至少移动一次间谍后才能进入下一阶段。'
        : '追捕阶段：所有未被【宵禁令】影响的阵营，都必须至少部署/移动一次追捕者后才能进入下一阶段。'
    };
  }
  return { ok: true };
}

function advancePhase(state) {
  const ok = canAdvancePhase(state);
  if (!ok.ok) return ok;

  // 清理阶段计数
  state.cardsUsedThisPhase.A = false;
  state.cardsUsedThisPhase.B = false;
  state.movesThisPhase.A = 0;
  state.movesThisPhase.B = 0;

  if (state.phase === 'deploy') {
    state.phase = 'hunt';
    addLog(state, { text: `R${state.round} · 阶段切换：从部署阶段进入追捕阶段。`, vis: 'ALL' });
  } else {
    // 回合结束：冻结回合数递减
    if (state.A.frozenRounds > 0) state.A.frozenRounds -= 1;
    if (state.B.frozenRounds > 0) state.B.frozenRounds -= 1;

    state.round += 1;
    state.phase = 'deploy';
    addLog(state, { text: `回合：进入第 ${state.round} 回合（部署阶段）。`, vis: 'ALL' });
  }

  return { ok: true };
}

function applyPlayCard(state, side, cardName, payload) {
  if (state.over) return { ok: false, err: '游戏已结束。' };
  if (side !== 'A' && side !== 'B') return { ok: false, err: '非法阵营。' };
  const p = state[side];
  if (p.frozenRounds > 0) return { ok: false, err: '你受到【宵禁令】影响，本回合无法行动。' };

  if (state.cardsUsedThisPhase[side]) {
    return { ok: false, err: '本阶段你已经使用过锦囊。' };
  }

  if (!p.cards[cardName] || p.cards[cardName] <= 0) {
    return { ok: false, err: '你没有这张牌。' };
  }

  // MVP：只做“消耗 + 记录 +（可选）少量可自动判定”的框架
  // 复杂效果请逐张往这里填。
  p.cards[cardName] -= 1;
  state.cardsUsedThisPhase[side] = true;

  // 对玩家：可以看到自己用了什么牌
  addLog(state, { text: `R${state.round} · 锦囊：你使用了【${cardName}】。`, vis: side });
  // 对裁判：看到完整
  addLog(state, { text: `R${state.round} · 锦囊：${side}方使用【${cardName}】。 payload=${JSON.stringify(payload ?? {})}`, vis: 'REF' });

  // 对对方：默认不提示（满足“玩家不知道对方是否使用卡牌”）

  // 例：宵禁令（MVP先做一个真正影响回合的效果）
  if (cardName === '宵禁令') {
    const target = payload?.target;
    if (target !== 'A' && target !== 'B') return { ok: false, err: '宵禁令需要指定目标 A 或 B。' };
    state[target].frozenRounds = Math.max(state[target].frozenRounds, 1);

    // 被宵禁的一方能看到结果（但不必知道对方用了什么牌—你可以选择只告诉“你被限制行动”）
    addLog(state, { text: `【宵禁令】你在下个回合将无法行动。`, vis: target });
    addLog(state, { text: `【宵禁令】${target}方冻结 1 回合。`, vis: 'REF' });
  }

  return { ok: true };
}

function maskForRole(state, role, seat) {
  // seat: 'A'|'B'|null
  // role: 'REF'|'SPECTATOR'|'A'|'B'
  if (role === 'REF' || role === 'SPECTATOR') {
    return {
      kind: 'ref_view',
      truth: state,
      log: state.log
    };
  }

  const side = seat; // 'A' or 'B'
  const opp = side === 'A' ? 'B' : 'A';

  // 玩家视图：对方位置/手牌不下发
  return {
    kind: 'player_view',
    side,
    round: state.round,
    phase: state.phase,
    over: state.over,
    movesThisPhase: { [side]: state.movesThisPhase[side] },
    cardsUsedThisPhase: { [side]: state.cardsUsedThisPhase[side] },
    self: {
      spyPos: state[side].spyPos,
      hunterPos: state[side].hunterPos,
      frozenRounds: state[side].frozenRounds,
      cards: state[side].cards
    },
    // 为了 UI 提示“对方是否被冻结”等也不下发（避免侧信道）
    // 你若未来想让玩家知道“对方被冻结”，可以改成只在规则允许时透出。

    log: state.log.filter(e => e.vis === 'ALL' || e.vis === side)
  };
}

/**
 * Room structure:
 * {
 *   code,
 *   createdAt,
 *   hostToken,
 *   refToken,
 *   seats: { A: token|null, B: token|null, REF: token|null },
 *   clients: Map<token, { ws, nick, role, seat }>,
 *   state: truthState
 * }
 */

const rooms = new Map();

function getRoom(code) {
  return rooms.get(code);
}

function broadcastRoom(room) {
  for (const [token, c] of room.clients.entries()) {
    if (c.ws.readyState !== 1) continue;

    const view = maskForRole(room.state, c.role, c.seat);
    const roster = [...room.clients.entries()].map(([t, cc]) => ({
      token: t,
      nick: cc.nick,
      role: cc.role,
      seat: cc.seat
    }));

    c.ws.send(JSON.stringify({
      type: 'ROOM_SNAPSHOT',
      room: {
        code: room.code,
        hostToken: room.hostToken,
        refToken: room.refToken,
        seats: room.seats
      },
      self: { token, nick: c.nick, role: c.role, seat: c.seat },
      roster,
      view
    }));
  }
}

function send(ws, obj) {
  if (ws.readyState !== 1) return;
  ws.send(JSON.stringify(obj));
}

function makeRoom() {
  let code = randCode(6);
  while (rooms.has(code)) code = randCode(6);

  const room = {
    code,
    createdAt: Date.now(),
    hostToken: null,
    refToken: null,
    seats: { A: null, B: null, REF: null },
    clients: new Map(),
    state: defaultTruthState(),
    emptySince: null
  };
  rooms.set(code, room);
  return room;
}

function cleanupRooms() {
  const now = Date.now();
  for (const [code, room] of rooms.entries()) {
    if (room.clients.size > 0) {
      room.emptySince = null;
      continue;
    }
    if (room.emptySince == null) room.emptySince = now;
    // 空房间 10 分钟销毁
    if (now - room.emptySince > 10 * 60 * 1000) rooms.delete(code);
  }
}
setInterval(cleanupRooms, 30 * 1000);

function ensureHostAndRef(room, token) {
  // 第一个进房间的人自动当 Host + Ref
  if (!room.hostToken) room.hostToken = token;
  if (!room.refToken) room.refToken = token;
  if (!room.seats.REF) room.seats.REF = token;
}

function assignRoleFromSeats(room, token) {
  const seatA = room.seats.A === token;
  const seatB = room.seats.B === token;
  const seatR = room.seats.REF === token;

  if (seatR) return { role: 'REF', seat: null };
  if (seatA) return { role: 'A', seat: 'A' };
  if (seatB) return { role: 'B', seat: 'B' };
  return { role: 'SPECTATOR', seat: null };
}

function mustBeHost(room, token) {
  return room.hostToken === token;
}

function mustBeRef(room, token) {
  return room.refToken === token;
}

wss.on('connection', (ws) => {
  const sessionToken = newToken();

  // 先给客户端一个 sessionToken；客户端也会提供自己的 clientToken（用于重连）
  send(ws, { type: 'HELLO', sessionToken });

  ws.on('message', (buf) => {
    let msg;
    try {
      msg = JSON.parse(buf.toString('utf-8'));
    } catch {
      send(ws, { type: 'ERROR', message: '消息格式错误（非 JSON）。' });
      return;
    }

    const type = msg?.type;

    // --- 连接/加入/创建 ---
    if (type === 'CREATE_ROOM') {
      const nickRaw = msg?.nick;
      const clientToken = msg?.clientToken || newToken();

      const room = makeRoom();
      const nick = clampNick(nickRaw);

      // 记录 client
      room.clients.set(clientToken, { ws, nick, role: 'SPECTATOR', seat: null });
      ensureHostAndRef(room, clientToken);
      const rr = assignRoleFromSeats(room, clientToken);
      room.clients.get(clientToken).role = rr.role;
      room.clients.get(clientToken).seat = rr.seat;

      // 初始化日志
      addLog(room.state, { text: `房间创建成功。房间号：${room.code}`, vis: 'ALL' });

      send(ws, { type: 'ROOM_CREATED', roomCode: room.code, clientToken });
      broadcastRoom(room);
      return;
    }

    if (type === 'JOIN_ROOM') {
      const roomCode = String(msg?.roomCode ?? '').trim().toUpperCase();
      const nickRaw = msg?.nick;
      const clientToken = msg?.clientToken || newToken();

      const room = getRoom(roomCode);
      if (!room) {
        send(ws, { type: 'ERROR', message: '房间不存在或已关闭。' });
        return;
      }

      // 昵称去重
      const taken = new Set([...room.clients.values()].map(c => c.nick));
      const desired = clampNick(nickRaw);
      const nick = uniqNick(desired, taken);

      room.clients.set(clientToken, { ws, nick, role: 'SPECTATOR', seat: null });
      ensureHostAndRef(room, clientToken);

      const rr = assignRoleFromSeats(room, clientToken);
      room.clients.get(clientToken).role = rr.role;
      room.clients.get(clientToken).seat = rr.seat;

      addLog(room.state, { text: `${nick} 加入了房间。`, vis: 'ALL' });

      send(ws, { type: 'ROOM_JOINED', roomCode: room.code, clientToken });
      broadcastRoom(room);
      return;
    }

    // 之后的消息都需要 roomCode + clientToken
    const roomCode = String(msg?.roomCode ?? '').trim().toUpperCase();
    const clientToken = String(msg?.clientToken ?? '').trim();
    const room = getRoom(roomCode);
    if (!room || !room.clients.has(clientToken)) {
      send(ws, { type: 'ERROR', message: '未加入房间或房间不存在。' });
      return;
    }

    const client = room.clients.get(clientToken);
    client.ws = ws; // 允许重连后复用 token

    // --- Host 管理 ---
    if (type === 'HOST_ASSIGN_SEAT') {
      if (!mustBeHost(room, clientToken)) {
        send(ws, { type: 'ERROR', message: '只有房主可以分配席位。' });
        return;
      }
      const targetToken = String(msg?.targetToken ?? '').trim();
      const seat = msg?.seat; // 'A'|'B'|'REF'|'SPECTATOR'
      if (!room.clients.has(targetToken)) {
        send(ws, { type: 'ERROR', message: '目标玩家不在房间里。' });
        return;
      }

      // 清理旧占座
      if (seat === 'A' || seat === 'B' || seat === 'REF') {
        // seat 被别人占用则挤掉（变观众）
        const current = room.seats[seat];
        if (current && room.clients.has(current)) {
          const cc = room.clients.get(current);
          cc.role = 'SPECTATOR';
          cc.seat = null;
        }
      }

      // 先把 target 从所有 seat 移除
      for (const k of ['A', 'B', 'REF']) {
        if (room.seats[k] === targetToken) room.seats[k] = null;
      }

      if (seat === 'A' || seat === 'B') {
        room.seats[seat] = targetToken;
      } else if (seat === 'REF') {
        room.seats.REF = targetToken;
        room.refToken = targetToken;
      } else {
        // spectator
      }

      // 重新计算所有人 role
      for (const [t, cc] of room.clients.entries()) {
        const rr = assignRoleFromSeats(room, t);
        cc.role = rr.role;
        cc.seat = rr.seat;
      }

      addLog(room.state, { text: `房主调整席位分配。`, vis: 'ALL' });
      broadcastRoom(room);
      return;
    }

    if (type === 'HOST_TRANSFER') {
      if (!mustBeHost(room, clientToken)) {
        send(ws, { type: 'ERROR', message: '只有房主可以转移房主权限。' });
        return;
      }
      const targetToken = String(msg?.targetToken ?? '').trim();
      if (!room.clients.has(targetToken)) {
        send(ws, { type: 'ERROR', message: '目标玩家不在房间里。' });
        return;
      }
      // 你要求：转移房主 = 指定对方为裁判，并且自己失权
      room.hostToken = targetToken;
      room.refToken = targetToken;
      room.seats.REF = targetToken;

      // 把原 host 从 REF seat 挤出（如果他是 REF）
      // 同时不强制他必须离开 A/B seat（但一般你会让他当观众）
      const prev = clientToken;
      if (room.seats.A === targetToken || room.seats.B === targetToken) {
        // ok
      }
      // 如果 target 原来在 A/B seat，也允许他继续在 A/B 的同时担任裁判？
      // 为避免混乱：当 REF 时默认取消 A/B seat。
      if (room.seats.A === targetToken) room.seats.A = null;
      if (room.seats.B === targetToken) room.seats.B = null;

      for (const [t, cc] of room.clients.entries()) {
        const rr = assignRoleFromSeats(room, t);
        cc.role = rr.role;
        cc.seat = rr.seat;
      }

      addLog(room.state, { text: `房主已转移。新的裁判/房主已接管。`, vis: 'ALL' });
      broadcastRoom(room);
      return;
    }

    // --- 游戏控制 ---
    if (type === 'START_GAME') {
      if (!mustBeRef(room, clientToken)) {
        send(ws, { type: 'ERROR', message: '只有裁判可以开始/重置游戏。' });
        return;
      }
      room.state = defaultTruthState();
      addLog(room.state, { text: '游戏已开始/重置。', vis: 'ALL' });
      broadcastRoom(room);
      return;
    }

    if (type === 'ADVANCE_PHASE') {
      if (!mustBeRef(room, clientToken)) {
        send(ws, { type: 'ERROR', message: '只有裁判可以推进阶段。' });
        return;
      }
      const res = advancePhase(room.state);
      if (!res.ok) {
        send(ws, { type: 'ERROR', message: res.err });
        return;
      }
      broadcastRoom(room);
      return;
    }

    // --- 玩家动作 ---
    if (type === 'MOVE') {
      const piece = msg?.piece; // 'spy'|'hunter'
      const to = msg?.to;

      if (client.role !== 'A' && client.role !== 'B') {
        send(ws, { type: 'ERROR', message: '只有玩家可以移动。' });
        return;
      }
      const side = client.role;
      const res = applyMove(room.state, side, piece, to);
      if (!res.ok) {
        send(ws, { type: 'ERROR', message: res.err });
        return;
      }
      broadcastRoom(room);
      return;
    }

    if (type === 'PLAY_CARD') {
      const cardName = String(msg?.cardName ?? '').trim();
      const payload = msg?.payload;

      if (client.role !== 'A' && client.role !== 'B') {
        send(ws, { type: 'ERROR', message: '只有玩家可以使用锦囊。' });
        return;
      }
      const side = client.role;
      const res = applyPlayCard(room.state, side, cardName, payload);
      if (!res.ok) {
        send(ws, { type: 'ERROR', message: res.err });
        return;
      }
      broadcastRoom(room);
      return;
    }

    send(ws, { type: 'ERROR', message: `未知消息类型：${type}` });
  });

  ws.on('close', () => {
    // 断线时不立即踢掉 token（保留 10 分钟重连由 cleanupRooms 处理）
    // 这里不做任何事。
  });
});

server.listen(PORT, () => {
  console.log(`beiguo-online listening on http://localhost:${PORT}`);
});
